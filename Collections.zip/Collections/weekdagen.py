weekdagen = ["Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag", "Zondag"]


print ("Alle dagen:",weekdagen)
print ("Werkdagen:", weekdagen[0:5])
print ("weekend dagen:",weekdagen[5:])
weekdagen.reverse()
print("Omgedraaid:",weekdagen)
print("Werkdagen Omgedraaid:",weekdagen[2:])
print("Weekend dagen omgedraaid:",weekdagen[:2])